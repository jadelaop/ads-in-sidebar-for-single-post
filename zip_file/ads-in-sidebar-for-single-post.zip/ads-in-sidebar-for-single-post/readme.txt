=== ADS IN SIDEBAR FOR SINGLE POST ===
Contributors: Jose A. de la O
Tags: ad, ads, adsense, advertising, Post, posts, widget
Requires at least: 2.8
Tested up to: 4.0

Add HTML Code advertising to Sidebar. For each single post you will display a different ads in Sidebar with a Widget.
Automatic integration with themes.

== Description ==

You can add a widget in post sidebar, and edit ads that will display in this widget for each post.


== Installation and config ==

1. Download zip file in zip folder.

2. Upload zip file in plugins admin interface or Wordpress.

3. Activate the plugin through the 'Plugins' menu in WordPress

4. Drag Ads for Post widget to your Sidebar and set title if you want in Widgets configuration.

5. Add advertising code to Ads for Post box in single post edit page.
